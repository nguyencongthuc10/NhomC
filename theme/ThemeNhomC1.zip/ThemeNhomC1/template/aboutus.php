
<?php 
	/* template name:aboutus*/

 ?>
<?php get_header(); ?>
 <?php get_template_part('/assets/Module/15', 'content');   ?>
  <?php get_template_part('/assets/Module/16', 'content');   ?>
   <?php get_template_part('/assets/Module/17', 'content');   ?>
   <?php get_template_part('/assets/Module/5', 'content');   ?>
    <?php get_template_part('/assets/Module/19', 'content');   ?>
    <?php get_template_part('/assets/Module/13', 'content');   ?>


<?php get_footer(); ?>