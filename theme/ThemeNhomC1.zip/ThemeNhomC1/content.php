<?php  

   get_template_part('/assets/Module/2', 'content'); 
   get_template_part('/assets/Module/3', 'content'); 
   get_template_part('/assets/Module/18', 'content'); 
   get_template_part('/assets/Module/4', 'content'); 
   get_template_part('/assets/Module/6', 'content'); 
   get_template_part('/assets/Module/7', 'content'); 
   get_template_part('/assets/Module/8', 'content'); 
   get_template_part('/assets/Module/10', 'content'); 
   get_template_part('/assets/Module/11', 'content'); 
   get_template_part('/assets/Module/12', 'content'); 
    get_template_part('/assets/Module/13', 'content'); 
 ?>